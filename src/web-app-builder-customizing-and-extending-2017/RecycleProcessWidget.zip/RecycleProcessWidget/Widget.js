define(['dojo/_base/declare', 'jimu/BaseWidget'],
  function(declare, BaseWidget) {
    //To create a widget, you need to derive from BaseWidget.
    return declare([BaseWidget], {
      // Custom widget code goes here

      baseClass: 'jimu-widget-customwidget',

      //this property is set by the framework when widget is loaded.
      //name: 'CustomWidget',


      //methods to communication with app container:

      postCreate: function() {
        this.inherited(arguments);
        console.log('postCreate');
        this.projectsLayer = this.map.getLayer('Existing_Recycling_Projects_635');
      },

      // startup: function() {
      //  this.inherited(arguments);
      //  this.mapIdNode.innerHTML = 'map id:' + this.map.id;
      //  console.log('startup');
      // },

      onOpen: function(){
        console.log('onOpen');
        this.projectsLayer.show();
      },

      onClose: function(){
        console.log('onClose');
        this.projectsLayer.hide();
      },

      buttonClickEventHandler: function() {
        this.map.on('click', function(evt) {
          console.log('evt', evt.mapPoint);
          alert('Sending to third party system: (' + evt.mapPoint.x + ',' + evt.mapPoint.y + ') to ' + this.config.thirdPartySystemUrl);
        }.bind(this))
      },

      // onMinimize: function(){
      //   console.log('onMinimize');
      // },

      // onMaximize: function(){
      //   console.log('onMaximize');
      // },

      // onSignIn: function(credential){
      //   /* jshint unused:false*/
      //   console.log('onSignIn');
      // },

      // onSignOut: function(){
      //   console.log('onSignOut');
      // }

      // onPositionChange: function(){
      //   console.log('onPositionChange');
      // },

      // resize: function(){
      //   console.log('resize');
      // }

      //methods to communication between widgets:

    });
  });
