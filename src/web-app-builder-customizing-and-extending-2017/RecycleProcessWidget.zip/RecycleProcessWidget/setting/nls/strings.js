define({
  root: ({
    serviceUrl: 'Third Party Report Submit URL:'
  })
});
