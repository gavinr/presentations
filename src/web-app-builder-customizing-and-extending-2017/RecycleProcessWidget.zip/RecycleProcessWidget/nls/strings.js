define({
    root:({
        addLocation: 'Add Location'
    }),
    "es": true
});
